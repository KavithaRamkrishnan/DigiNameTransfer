import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";
import { NativeScriptFormsModule } from "nativescript-angular/forms";

import { DocuploadRoutingModule } from "./docupload-routing.module";
import { DocuploadComponent } from "./docupload.component";

@NgModule({
	imports: [
		NativeScriptCommonModule,
		NativeScriptFormsModule,
		DocuploadRoutingModule
	],
	declarations: [
		DocuploadComponent
	],
	schemas: [
		NO_ERRORS_SCHEMA
	]
})

export class DocuploadModule { }