import { ItemEventData } from "ui/list-view"
import { Component, OnInit } from "@angular/core";



@Component({
	selector: "Docupload",
	moduleId: module.id,
	templateUrl: "./docupload.component.html",
	styleUrls: ['./docupload.component.css']
})
export class DocuploadComponent implements OnInit {
    onButtonTap(): void {
        console.log("Button was pressed");
    }


	constructor() {
	}

	ngOnInit(): void {
	}
}