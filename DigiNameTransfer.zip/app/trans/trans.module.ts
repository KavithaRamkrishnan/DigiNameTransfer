import { NgModule, NO_ERRORS_SCHEMA } from "@angular/core";
import { NativeScriptCommonModule } from "nativescript-angular/common";
import { NativeScriptFormsModule } from "nativescript-angular/forms";

import { TransRoutingModule } from "./trans-routing.module";
import { TransComponent } from "./trans.component";

@NgModule({
	imports: [
		NativeScriptCommonModule,
		NativeScriptFormsModule,
		TransRoutingModule
	],
	declarations: [
		TransComponent
	],
	schemas: [
		NO_ERRORS_SCHEMA
	]
})
export class TransModule { }