import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { alert, prompt } from "tns-core-modules/ui/dialogs";
import { Page } from "tns-core-modules/ui/page";

@Component({
	selector: "app-trans",
	moduleId: module.id,
	templateUrl: "./trans.component.html",
	styleUrls: ['./trans.component.css']
})
export class TransComponent implements OnInit {
	

	textFieldValue: string = "";


	constructor(private router: Router) {


	}
	onButtonTap(): void {

		this.router.navigate(["/docupload"]);
	}




	ngOnInit(): void {
	}
}