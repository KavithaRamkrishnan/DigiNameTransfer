import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { alert, prompt } from "tns-core-modules/ui/dialogs";
import { Page } from "tns-core-modules/ui/page";

@Component({
    selector: "app-home",
    moduleId: module.id,
    templateUrl: "./home.component.html",
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {



    constructor(private router: Router) {
    }
    onButtonTap(): void {

        this.router.navigate(["/trans"]);
    }

    onNavBtnTap(): void {

        this.router.navigate(["/login"]);
    }


    ngOnInit(): void {
    }
}